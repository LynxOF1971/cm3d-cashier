/* CM3D cashier API. Deploy as owner. All data actions require a session.
   No credentials or spreadsheet identifiers belong in public/config.json. */
function props_() { return PropertiesService.getScriptProperties(); }
function fail_(message, code) { var e=new Error(message);e.code=code||'INVALID';throw e; }
function hash_(value) { return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,value,Utilities.Charset.UTF_8).map(function(b){return ('0'+((b+256)%256).toString(16)).slice(-2);}).join(''); }
function equal_(a,b) { if(typeof a!=='string'||typeof b!=='string')return false;var diff=a.length^b.length;for(var i=0;i<Math.max(a.length,b.length);i++)diff|=(a.charCodeAt(i)||0)^(b.charCodeAt(i)||0);return diff===0; }
function json_(data) { return ContentService.createTextOutput(JSON.stringify(data)).setMimeType(ContentService.MimeType.JSON); }
function doGet() { return json_({ok:false,message:'Use the cashier app.'}); }
function doPost(e) {
  try {
    var raw=e&&e.postData&&e.postData.contents;
    if(!raw||raw.length>12000)fail_('Invalid request.');
    var b;try{b=JSON.parse(raw);}catch(_){fail_('Invalid request.');}
    if(!b||typeof b!=='object')fail_('Invalid request.');
    var p=props_();
    if(!p.getProperty('PASSWORD_VERIFIER')||!p.getProperty('PASSWORD_SALT')||!p.getProperty('CASHIER_USERNAME')||!p.getProperty('SPREADSHEET_ID'))fail_('The owner needs to finish setup.','SETUP');
    if(b.action==='config')return json_({ok:true,salt:p.getProperty('PASSWORD_SALT')});
    if(b.action==='login')return json_(login_(b));
    var key=authorize_(b.token);
    if(b.action==='logout'){p.deleteProperty(key);return json_({ok:true});}
    if(b.action==='list')return json_(list_(b.page));
    if(b.action==='create')return json_(create_(b));
    fail_('Action not available.');
  } catch(err) { return json_({ok:false,code:err.code||'SERVER',message:err.code?err.message:'The order service is unavailable. Please retry or contact the owner.'}); }
}
function login_(b) {
  var lock=LockService.getScriptLock();lock.waitLock(10000);
  try {
    var p=props_(),now=Date.now(),state=JSON.parse(p.getProperty('LOGIN_RATE')||'{"count":0,"until":0}');
    if(state.until>now&&state.count>=5)fail_('Too many sign-in attempts. Try again in 5 minutes.','RATE');
    if(state.until<=now)state={count:0,until:now+300000};
    var valid=typeof b.proof==='string'&&/^[a-f0-9]{64}$/.test(b.proof)&&equal_(hash_(b.proof),p.getProperty('PASSWORD_VERIFIER'))&&equal_(b.username,p.getProperty('CASHIER_USERNAME'));
    if(!valid){state.count++;p.setProperty('LOGIN_RATE',JSON.stringify(state));fail_('Incorrect username or password.','LOGIN');}
    p.deleteProperty('LOGIN_RATE');
    var all=p.getProperties();Object.keys(all).filter(function(k){return k.indexOf('SESSION_')===0;}).forEach(function(k){p.deleteProperty(k);});
    var token=Utilities.getUuid()+Utilities.getUuid();
    p.setProperty('SESSION_'+hash_(token),JSON.stringify({expires:now+8*60*60*1000,version:hash_(p.getProperty('PASSWORD_VERIFIER'))}));
    return {ok:true,token:token};
  } finally { lock.releaseLock(); }
}
function authorize_(token) {
  if(typeof token!=='string'||!/^[-a-f0-9]{72}$/.test(token))fail_('Please sign in again.','AUTH');
  var p=props_(),key='SESSION_'+hash_(token),record=JSON.parse(p.getProperty(key)||'null');
  if(!record||record.expires<=Date.now()||record.version!==hash_(p.getProperty('PASSWORD_VERIFIER'))){p.deleteProperty(key);fail_('Please sign in again.','AUTH');}
  return key;
}
function sheet_() {
  var sheet=SpreadsheetApp.openById(props_().getProperty('SPREADSHEET_ID')).getSheetByName('Sheet1');
  if(!sheet)fail_('Sheet1 is unavailable. Contact the owner.','SETUP');
  var headers=sheet.getRange(1,1,1,11).getDisplayValues()[0].map(function(s){return s.replace(/\s+/g,' ').trim().toLowerCase();});
  var expected=['date','customer name','address','contact number','quantity','design details (names) + color','total price (without dc)','delivery status','overall status','realtime income','after steadfast penalty'];
  if(headers.some(function(h,i){return h!==expected[i];}))fail_('Sheet columns have changed. Contact the owner.','SETUP');
  return sheet;
}
function list_(page) {
  page=page===undefined?0:page;if(!Number.isInteger(page)||page<0||page>10000)fail_('Invalid page.');
  var s=sheet_(),n=s.getLastRow()-1;if(n<1)return {ok:true,orders:[],nextPage:null};
  // Only these three columns are read. A whitelist prevents accidental expansion.
  var names=s.getRange(2,2,n,1).getDisplayValues(),phones=s.getRange(2,4,n,1).getDisplayValues(),statuses=s.getRange(2,8,n,1).getDisplayValues();
  var result=[];for(var i=n-1;i>=0;i--){if(names[i][0].trim())result.push({name:names[i][0],phone:phones[i][0],status:['Delivered','Not Delivered'].indexOf(statuses[i][0])>=0?statuses[i][0]:'Pending'});}
  var start=page*50;return {ok:true,orders:result.slice(start,start+50),nextPage:start+50<result.length?page+1:null};
}
function text_(v,label,max,optional) { if(typeof v!=='string'||v.length>max||(!optional&&!v.trim()))fail_('Check '+label+'.');return v.trim(); }
function validate_(o) {
  if(!o||typeof o!=='object')fail_('Order details are required.');
  var name=text_(o.name,'customer name',120),phone=text_(o.phone,'phone number',24),address=text_(o.address,'address',800),design=text_(o.design,'design',1000,true),date=text_(o.date,'date',10);
  if(!/^\+?[0-9 ()-]{7,24}$/.test(phone)||phone.replace(/\D/g,'').length<7)fail_('Check phone number.');
  if(!/^\d{4}-\d{2}-\d{2}$/.test(date))fail_('Check order date.');
  var stamp=Date.parse(date+'T00:00:00Z');if(!Number.isFinite(stamp)||new Date(stamp).toISOString().slice(0,10)!==date||date<'2000-01-01'||date>'2100-12-31')fail_('Check order date.');
  if(!Number.isInteger(o.quantity)||o.quantity<1||o.quantity>10000)fail_('Quantity must be a whole number from 1 to 10,000.');
  if(typeof o.price!=='number'||!Number.isFinite(o.price)||o.price<0||o.price>10000000||Math.abs(o.price*100-Math.round(o.price*100))>0.00001)fail_('Check selling price.');
  return {name:name,phone:phone,address:address,design:design,dateSerial:stamp/86400000+25569,quantity:o.quantity,price:o.price};
}
function create_(b) {
  if(typeof b.requestId!=='string'||!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(b.requestId))fail_('Invalid submission ID.');
  var o=validate_(b.order),lock=LockService.getScriptLock();lock.waitLock(20000);
  try {
    // Validate again inside the lock: a password rotation or logout may have occurred.
    authorize_(b.token);
    var s=sheet_(),n=s.getMaxRows(),sid=s.getSheetId(),requests=[];
    if(s.getMaxColumns()<32)fail_('Column AF is required. Contact the owner.','SETUP');
    var idHeader=s.getRange(1,32).getDisplayValue();
    if(idHeader&&idHeader!=='Cashier submission ID')fail_('Column AF is already in use. Contact the owner.','SETUP');
    var ids=s.getRange(2,32,n-1,1).getDisplayValues();
    if(!idHeader&&ids.some(function(r){return r[0]!=='';}))fail_('Column AF is already in use. Contact the owner.','SETUP');
    if(ids.some(function(r){return r[0]===b.requestId;}))return {ok:true};
    // Ignore prefilled income formulas and the independent expense/salary blocks.
    var data=s.getRange(2,1,n-1,8).getDisplayValues(),row=2;
    for(var i=data.length-1;i>=0;i--)if(data[i].some(function(v){return v!=='';})){row=i+3;break;}
    if(row>n)requests.push({appendDimension:{sheetId:sid,dimension:'ROWS',length:100}});
    var str=function(v){return {userEnteredValue:{stringValue:v}};},num=function(v){return {userEnteredValue:{numberValue:v}};},formula=function(v){return {userEnteredValue:{formulaValue:v}};};
    var values=[num(o.dateSerial),str(o.name),str(o.address),str(o.phone),num(o.quantity),str(o.design),num(o.price),str('Not Delivered'),num(0),formula('=G'+row+'*I'+row),formula('=J'+row+'-INT(J'+row+'/100)')];
    // Typed stringValue writes keep names/designs starting with '=' inert.
    requests.push({updateCells:{range:{sheetId:sid,startRowIndex:row-1,endRowIndex:row,startColumnIndex:0,endColumnIndex:11},rows:[{values:values}],fields:'userEnteredValue'}});
    requests.push({updateCells:{range:{sheetId:sid,startRowIndex:row-1,endRowIndex:row,startColumnIndex:31,endColumnIndex:32},rows:[{values:[str(b.requestId)]}],fields:'userEnteredValue'}});
    if(!idHeader)requests.push({updateCells:{range:{sheetId:sid,startRowIndex:0,endRowIndex:1,startColumnIndex:31,endColumnIndex:32},rows:[{values:[str('Cashier submission ID')]}],fields:'userEnteredValue'}});
    requests.push({repeatCell:{range:{sheetId:sid,startRowIndex:row-1,endRowIndex:row,startColumnIndex:0,endColumnIndex:1},cell:{userEnteredFormat:{numberFormat:{type:'DATE',pattern:'d-m-yy'}}},fields:'userEnteredFormat.numberFormat'}});
    requests.push({repeatCell:{range:{sheetId:sid,startRowIndex:row-1,endRowIndex:row,startColumnIndex:3,endColumnIndex:4},cell:{userEnteredFormat:{numberFormat:{type:'TEXT'}}},fields:'userEnteredFormat.numberFormat'}});
    // One atomic Sheets batch writes both the order and its deduplication ID.
    var response=UrlFetchApp.fetch('https://sheets.googleapis.com/v4/spreadsheets/'+encodeURIComponent(props_().getProperty('SPREADSHEET_ID'))+':batchUpdate',{method:'post',contentType:'application/json',headers:{Authorization:'Bearer '+ScriptApp.getOAuthToken()},payload:JSON.stringify({requests:requests}),muteHttpExceptions:true});
    if(response.getResponseCode()!==200)fail_('Could not save the order. Retry this submission.','SAVE');
    return {ok:true};
  } finally {lock.releaseLock();}
}
