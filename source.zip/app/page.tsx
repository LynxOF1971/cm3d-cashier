'use client';
import { useEffect, useRef, useState, type FormEvent } from 'react';
import { LockKeyhole, LogOut, Plus, List, ArrowRight, Check, RefreshCw } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
type Order = { name: string; phone: string; status: string };
type ApiResult = { ok: boolean; code?: string; message?: string; token?: string; salt?: string; orders?: Order[]; nextPage?: number | null };
const today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
export default function App() {
  const [api,setApi]=useState(''); const [configured,setConfigured]=useState<boolean|null>(null);
  const [token,setToken]=useState(''); const [view,setView]=useState('new');
  const [orders,setOrders]=useState<Order[]>([]); const [nextPage,setNextPage]=useState<number|null>(null);
  const [busy,setBusy]=useState(false); const [error,setError]=useState(''); const [notice,setNotice]=useState('');
  const [uncertain,setUncertain]=useState(false);
  const pending=useRef<{requestId:string;order:Record<string,unknown>}|null>(null);
  const formRef=useRef<HTMLFormElement>(null);
  useEffect(()=>{fetch('./config.json',{cache:'no-store'}).then(r=>r.json()).then(c=>{const valid=/^https:\/\/script\.google\.com\/macros\/s\/[A-Za-z0-9_-]+\/exec$/.test(c.apiUrl);setApi(valid?c.apiUrl:'');setConfigured(valid);}).catch(()=>setConfigured(false));},[]);
  function clearSession(){setToken('');setOrders([]);pending.current=null;setUncertain(false);setNotice('');formRef.current?.reset();}
  async function call(action:string,data:Record<string,unknown>={}):Promise<ApiResult>{
    const response=await fetch(api,{method:'POST',redirect:'follow',credentials:'omit',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify({action,token,...data}),signal:AbortSignal.timeout(45000)});
    if(!response.ok)throw new Error('Connection failed. Please try again.');
    let result:ApiResult;try{result=await response.json();}catch{throw new Error('Could not connect to the order service. Please contact the owner.');}
    if(!result.ok){if(result.code==='AUTH')clearSession();throw Object.assign(new Error(result.message||'Request failed.'),{code:result.code});}return result;
  }
  async function login(e:FormEvent<HTMLFormElement>){
    e.preventDefault();setBusy(true);setError('');const form=e.currentTarget;const fields=new FormData(form);let password=String(fields.get('password'));form.reset();
    try{const settings=await call('config');if(!settings.salt)throw new Error('Login is not configured.');
      const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(password),'PBKDF2',false,['deriveBits']);password='';
      const bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt:new TextEncoder().encode(settings.salt),iterations:600000,hash:'SHA-256'},key,256);
      const proof=Array.from(new Uint8Array(bits),v=>v.toString(16).padStart(2,'0')).join('');
      const result=await call('login',{username:String(fields.get('username')).trim(),proof});
      if(!result.token)throw new Error('Login failed.');setToken(result.token);setView('new');
    }catch(err){setError((err as Error).message);}finally{password='';setBusy(false);}
  }
  async function loadOrders(page=0){setBusy(true);setError('');try{const r=await call('list',{page});setOrders(old=>page?[...old,...(r.orders||[])]:r.orders||[]);setNextPage(r.nextPage??null);}catch(err){setError((err as Error).message);}finally{setBusy(false);}}
  async function submit(e:FormEvent<HTMLFormElement>){
    e.preventDefault();setBusy(true);setError('');setNotice('');
    if(!pending.current){const d=Object.fromEntries(new FormData(e.currentTarget));pending.current={requestId:crypto.randomUUID(),order:{...d,quantity:Number(d.quantity),price:Number(d.price)}};}
    try{await call('create',pending.current);pending.current=null;setUncertain(false);formRef.current?.reset();setNotice('Order saved.');setView('orders');await loadOrders();}
    catch(err){const code=(err as Error & {code?:string}).code;const retry=!code||code==='SAVE'||code==='SERVER';if(!retry)pending.current=null;setError((err as Error).message+(retry?' If the connection was interrupted, use Retry to check this same order.':''));setUncertain(retry);}finally{setBusy(false);}
  }
  async function logout(){setBusy(true);try{await call('logout');}catch{/* Clear local state even offline. */}finally{clearSession();setError('');setBusy(false);}}
  return <div className="app-shell"><header className="topbar"><a className="wordmark" href="./">CM<span>3D</span><small>CASHIER</small></a>{token&&<button className="quiet" onClick={logout} disabled={busy}><LogOut size={17}/>Log out</button>}</header>
    <main>{!token?<section className="login-panel"><div className="lock-icon"><LockKeyhole size={26}/></div><p className="eyebrow">STAFF ACCESS</p><h1>Ready for the<br/>next order.</h1><p className="intro">Sign in to add orders and check their status.</p>
      {configured===false&&<div className="setup-notice" role="status">The owner needs to finish connecting this app before sign-in is available.</div>}{error&&<p className="error" role="alert">{error}</p>}
      <form onSubmit={login}><label>Username<input name="username" autoComplete="username" required maxLength={80} placeholder="Your username"/></label><label>Password<input name="password" type="password" autoComplete="current-password" required maxLength={256} placeholder="Enter your password"/></label><button className="primary" disabled={busy||!configured}>{busy?'Signing in…':'Sign in'}<ArrowRight size={18}/></button></form><p className="footnote">CM3D · Order desk</p></section>:<>
      <div className="page-heading"><div><p className="eyebrow">ORDER DESK</p><h1>{view==='new'?'Let’s take an order.':'Customer orders'}</h1></div><span className="staff-badge"><span/>Staff</span></div>
      {notice&&<p className="success" role="status"><Check size={18}/>{notice}</p>}{error&&<p className="error" role="alert">{error}</p>}
      <Tabs value={view} onValueChange={v=>{if(busy||uncertain)return;setView(String(v));setError('');setNotice('');if(v==='orders')void loadOrders();}}>
        <TabsList className="app-tabs"><TabsTrigger value="new" disabled={busy}><Plus size={18}/>New order</TabsTrigger><TabsTrigger value="orders" disabled={busy||uncertain}><List size={18}/>Orders</TabsTrigger></TabsList>
        <TabsContent value="new"><form ref={formRef} onSubmit={submit} className="order-form"><fieldset disabled={busy||uncertain}><section className="form-section"><div className="section-title"><span>01</span><h2>Customer details</h2></div><div className="fields"><label>Customer name<input name="name" required maxLength={120} autoComplete="off" placeholder="Full name"/></label><label>Phone number<input name="phone" type="tel" required minLength={7} maxLength={24} autoComplete="off" placeholder="01XXXXXXXXX"/></label><label className="wide">Delivery address<textarea name="address" required maxLength={800} rows={3} autoComplete="off" placeholder="House, road, area, city"/></label></div></section>
        <section className="form-section"><div className="section-title"><span>02</span><h2>Order details</h2></div><div className="fields"><label>Order date<input name="date" type="date" defaultValue={today()} required/></label><label>Quantity<input name="quantity" type="number" inputMode="numeric" min={1} max={10000} step={1} required placeholder="1"/></label><label className="wide">Design & colour<textarea name="design" rows={3} maxLength={1000} placeholder="Product, personalisation, names and colour"/></label><label>Total selling price<input name="price" type="number" inputMode="decimal" min={0} max={10000000} step="0.01" required placeholder="0.00"/><small>Excluding delivery charges</small></label></div></section></fieldset>
        <div className="submit-bar"><p>After saving, only the customer’s name, phone number and status are shown.</p><button className="primary" disabled={busy}>{busy?'Saving…':uncertain?'Retry same order':'Save order'}<ArrowRight size={18}/></button></div></form></TabsContent>
        <TabsContent value="orders"><section className="orders-panel"><div className="list-heading"><h2>Orders</h2><button className="quiet" disabled={busy} onClick={()=>loadOrders()}><RefreshCw size={16}/>Refresh</button></div>{!orders.length?<p className="empty">{busy?'Loading orders…':'No orders to show yet.'}</p>:<ul className="order-list">{orders.map((o,i)=><li key={i}><div><h3>{o.name}</h3><a href={`tel:${o.phone.replace(/[^+0-9]/g,'')}`}>{o.phone}</a></div><span className={o.status==='Delivered'?'status delivered':'status'}>{o.status}</span></li>)}</ul>}{nextPage!==null&&<button className="quiet load-more" disabled={busy} onClick={()=>loadOrders(nextPage)}>Load more</button>}</section></TabsContent>
      </Tabs></>}</main><footer>CM3D <span>•</span> Cashier workspace</footer></div>;
}
